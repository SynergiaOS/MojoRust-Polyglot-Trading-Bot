# Trading Strategy

**TODO:** This document is under development. It will explain the core trading strategies implemented in the bot.