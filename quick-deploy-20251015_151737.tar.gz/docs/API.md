# API Reference

**TODO:** This document is under development. It will detail the internal and external APIs used in the project.