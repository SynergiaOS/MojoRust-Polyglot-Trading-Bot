---
displayName: XXX
applicableFor: userQuery
---

<!--
Template to use while executing a user query directly in any agent.

Allowed tags:
- {{userQuery}}
-->
