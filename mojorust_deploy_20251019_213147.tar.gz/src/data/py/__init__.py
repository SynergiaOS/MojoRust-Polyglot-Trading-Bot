# =============================================================================
# Python Adapters Package
# =============================================================================
# This package provides Python async adapters for Mojo clients
# allowing seamless integration between Mojo and Python components

__version__ = "1.0.0"
__author__ = "MojoRust Trading Bot"